# sensehat_led_clock
RaspberryPi mounted SenseHat's 8x8 led clock as Python object
