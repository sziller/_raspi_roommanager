import time
try:
    from sense_hat import SenseHat
    imported_sense_hat = True
except ImportError:
    pass
    imported_sense_hat = False
from SenseHatLedDisplay import show_animated as anim
from SenseHatLedDisplay import show_pictures as pict


class LedDisplay:
    def __init__(self):
        if imported_sense_hat:
            self.sense = SenseHat()
            self.sense.low_light = False
        self.pattern_dict = {0: anim.mode_0,
                             1: anim.mode_1,
                             2: anim.mode_2}
        self.image_dict = {0: "sziv"}

        self.delta_t_h = 0
        self.delta_t_m = 0

    def run(self, dyn: bool = True, alias: int = 0, delay: float = 0.1, duration: int = 20,
            delta_t_h: float = 0, delta_t_m: float = 0):
        if delta_t_h: self.delta_t_h = delta_t_h
        if delta_t_m: self.delta_t_m = delta_t_m
        starting_time = time.time()
        ellapsed_time = 0
        if dyn:
            while ellapsed_time < duration:
                current_time = time.time()
                ellapsed_time = current_time - starting_time
                kwargs = {'coldict': COL_DICT, 'ellapsed': ellapsed_time}
                flatmat = self.pattern_dict[alias](**kwargs)
                if imported_sense_hat:
                    self.sense.set_pixels(flatmat)
                else:
                    print(flatmat)
                time.sleep(delay)
        else:
            kwargs = {'coldict': COL_DICT, 'title': self.image_dict[alias]}
            flatmat = pict.picture(**kwargs)
            if imported_sense_hat:
                self.sense.set_pixels(flatmat)
            else:
                print(flatmat)
            time.sleep(duration)


COL_DICT = {0: (0, 0, 0), 1: (0, 0, 0), 2: (0, 0, 0), 3: (0, 0, 0),
               4: (125, 0, 0), 5: (0, 125, 0), 6: (0, 0, 125),
               7: (125, 125, 0), 8: (125, 0, 125), 9: (0, 125, 125)}

if __name__ == "__main__":
    clock = LedDisplay()
    clock.run(duration=10)
